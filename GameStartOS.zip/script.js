function toggleStartMenu() {
  const menu = document.getElementById("startmenu");
  menu.classList.toggle("hidden");
}

function openApp(app) {
  const container = document.getElementById("window-container");
  const win = document.createElement("div");
  win.classList.add("window");
  win.style.top = Math.random() * 300 + "px";
  win.style.left = Math.random() * 300 + "px";
  win.innerHTML = "<strong>" + app + "</strong><br><br><em>Obsah aplikace...</em>";
  container.appendChild(win);
}

function updateClock() {
  const now = new Date();
  document.getElementById("clock").innerText = now.toLocaleTimeString();
}
setInterval(updateClock, 1000);
updateClock();
